import 'package:flutter/material.dart';
// Cores principais 
const Color corFundo = Color(0xFFF7F8FA);
const Color corBotao = Color(0xFF173B5E);
const Color corEscura = Color(0xFF142F4A);
const Color corBranca = Color(0xFFFFFFFF);

// Cores complementares

const Color corDestaque = Color(0xFFF2C500);
const Color corAzulClaro = Color (0xFFE8EEF4);
const Color corTextoSecundario = Color(0xFF64748B);
const Color corCabecalho = Color(0xFF285A8C);
