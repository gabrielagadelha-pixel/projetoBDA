const List<String> listaCursos = [
    // Graduação
    'Administração - Bacharelado',
    'Análise e Desenvolvimento de Sistemas - Tecnólogo',
    'Ciências Contábeis - Bacharelado',
    'Direito - Bacharelado',
    'Enfermagem - Bacharelado',
    'Gestão da Tecnologia da Informação - Tecnólogo',
    'Pedagogia - Licenciatura',
    'Optometria - Bacharelado',

    // Pós-graduação
    'Análises Clínicas com Ênfase em Microbiologia',
    'NeuroOptomeria',

     // Técnico
     'Técnico em Administração',
     'Técnico em Análises Clínicas',
     'Técnino em Enfermagem',
     'Técnico em Óptica',   
];
const Map<String, String> nomesCurtosCursos = {
  'Administração - Bacharelado': 'Administração',
  'Análise e Desenvolvimento de Sistemas - Tecnólogo': 'ADS',
  'Ciências Contábeis - Bacharelado': 'Ciências Contábeis',
  'Direito - Bacharelado': 'Direito',
  'Enfermagem - Bacharelado': 'Enfermagem',
  'Gestão da Tecnologia da Informação - Tecnólogo': 'GTI',
  'Pedagogia - Licenciatura': 'Pedagogia',
  'Optometria - Bacharelado': 'Optometria',
  'Análises Clínicas com Ênfase em Microbiologia': 'Pós Análises Clínicas',
  'NeuroOptometria': 'NeuroOptometria',
  'Técnico em Administração': 'Téc. Administração',
  'Técnico em Análises Clínicas': 'Téc. Análises Clínicas',
  'Técnico em Enfermagem': 'Téc. Enfermagem',
  'Técnico em Óptica': 'Téc. Óptica',
};

String nomeCurto(String curso) {
  return nomesCurtosCursos[curso] ?? curso;
}