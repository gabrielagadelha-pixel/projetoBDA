import '../models/usuario.dart';

class Sessao {
  static Usuario? usuarioAtual;

  static void entrar(Usuario usuario) {
    usuarioAtual = usuario;
  }

  static void sair() {
    usuarioAtual = null;
  }

  static bool get logado => usuarioAtual != null;
}