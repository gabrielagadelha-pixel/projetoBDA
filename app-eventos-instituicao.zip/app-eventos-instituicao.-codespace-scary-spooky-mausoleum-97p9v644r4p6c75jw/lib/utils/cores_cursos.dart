import 'package:flutter/material.dart';
import 'cores.dart';

class CoresCursos {
  static final Map<String, Color> _cores = {
    'Administração - Bacharelado': const Color(0xFFE91E63),
    'Análise e Desenvolvimento de Sistemas - Tecnólogo':
        const Color(0xFF1F1F1F),
    'Ciências Contábeis - Bacharelado': const Color(0xFF795548),
    'Direito - Bacharelado': const Color(0xFF3D4DE8),
    'Enfermagem - Bacharelado': const Color(0xFF2ECC40),
    'Gestão da Tecnologia da Informação - Tecnólogo':
        const Color(0xFF1DE9B6),
    'Pedagogia - Licenciatura': const Color(0xFFFF9A44),
    'Optometria - Bacharelado': const Color(0xFF00ACC1),
    'Análises Clínicas com Ênfase em Microbiologia':
        const Color(0xFF9E9D24),
    'NeuroOptometria': const Color(0xFF607D8B),
    'Técnico em Administração': const Color(0xFFFFB300),
    'Técnico em Análises Clínicas': const Color(0xFFE53935),
    'Técnico em Enfermagem': const Color(0xFF8BC34A),
    'Técnico em Óptica': const Color(0xFF039BE5),
  };

  static Color corDoCurso(String curso) {
    return _cores[curso] ?? corTextoSecundario;
  }

  static void definirCor(String curso, Color cor) {
    _cores[curso] = cor;
  }
}