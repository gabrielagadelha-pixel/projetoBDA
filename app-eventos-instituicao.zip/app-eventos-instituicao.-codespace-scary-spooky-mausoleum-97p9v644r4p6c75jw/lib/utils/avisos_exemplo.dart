import '../models/aviso.dart';

final List<Aviso> avisosExemplo = [
    Aviso(
        titulo: 'Solicitação atrasada',
        mensagem: 'Campanha interna de boas-vindas - entrega vencida',
        data: DateTime(2026, 11, 4),
        tipo: TipoAviso.alerta,
    ),
    Aviso(
        titulo: 'Prazo próximo',
        mensagem: 'Cartão de visita coordenação - entrega amanhã',
        data: DateTime(2026, 11, 4),
        tipo: TipoAviso.alerta,
    ),
    Aviso(
        titulo: 'Aguardando informações',
        mensagem: 'Folder do curso de Direito precisa de ajustes',
        data: DateTime(2026, 11, 3),
        tipo: TipoAviso.informacao,
    ),
    Aviso(
        titulo: 'Status alterado',
        mensagem: 'Semana Acadêmica de Administração está em produção',
        data: DateTime(2026, 11, 2),
        tipo: TipoAviso.informacao,
        lido: true,
    ),
    Aviso(
        titulo: 'Solicitação aprovada',
        mensagem: 'Notícia: aula inaugral de Pedagogia foi aprovada',
        data: DateTime(2026, 10, 10),
        tipo: TipoAviso.sucesso,
        lido: true,
    ),
];