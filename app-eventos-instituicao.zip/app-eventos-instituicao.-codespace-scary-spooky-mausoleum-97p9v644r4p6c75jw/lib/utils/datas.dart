String formatarData(DateTime data) {
  const meses = [
    'jan.', 'fev.', 'mar.', 'abr.', 'maio', 'jun.',
    'jul.', 'ago.', 'set.', 'out.', 'nov.', 'dez.',
  ];
  return '${data.day} de ${meses[data.month - 1]} de ${data.year}';
}