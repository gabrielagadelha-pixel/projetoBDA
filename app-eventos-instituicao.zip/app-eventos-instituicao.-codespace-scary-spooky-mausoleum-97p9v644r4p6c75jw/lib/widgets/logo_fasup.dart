import 'package:flutter/material.dart';
import '../utils/cores.dart';

class LogoFasup extends StatelessWidget {
  final double tamanho;

  const LogoFasup({
    super.key,
    required this.tamanho,
  });

  @override
  Widget build(BuildContext context) {
    return Image.asset(
      'assets/images/logo_fasup.jpg',
      width: tamanho,
      fit: BoxFit.contain,
      color: corFundo,
      colorBlendMode: BlendMode.multiply,
      errorBuilder: (context, error, stackTrace) {
        return SizedBox(
          width: tamanho,
          child: const Icon(
            Icons.school,
            color: corEscura,
            size: 55,
          ),
        );
      },
    );
  }
}