import 'package:flutter/material.dart';
import '../models/demanda.dart';
import '../utils/cores.dart';
import '../utils/cores_cursos.dart';
import '../utils/cursos.dart';
import '../telas/tela_relatorios.dart';

class SolicitacoesPorCurso extends StatelessWidget {
  final List<Demanda> demandas;

  const SolicitacoesPorCurso({
    super.key,
    required this.demandas,
  });

  @override
  Widget build(BuildContext context) {
    final Map<String, int> contagem = {};
    for (final demanda in demandas) {
      contagem[demanda.curso] = (contagem[demanda.curso] ?? 0) + 1;
    }

    int maior = 1;
    for (final quantidade in contagem.values) {
      if (quantidade > maior) {
        maior = quantidade;
      }
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: corBranca,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: corBotao),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Expanded(
                child: Text(
                  'Solicitações por cursos',
                  style: TextStyle(
                    color: corEscura,
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const TelaRelatorios(),
                    ),
                  );
                },
                child: const Row(
                  children: [
                    Icon(Icons.bar_chart, size: 16, color: corCabecalho),
                    SizedBox(width: 4),
                    Text(
                      'Relatórios',
                      style: TextStyle(
                        color: corCabecalho,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ...contagem.entries.map((entrada) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Row(
                children: [
                  SizedBox(
                    width: 110,
                    child: Text(
                      nomeCurto(entrada.key),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: corEscura,
                        fontSize: 13,
                      ),
                    ),
                  ),
                  Expanded(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: LinearProgressIndicator(
                        value: entrada.value / maior,
                        minHeight: 10,
                        color: CoresCursos.corDoCurso(entrada.key),
                        backgroundColor: corAzulClaro,
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Text(
                    '${entrada.value}',
                    style: const TextStyle(
                      color: corTextoSecundario,
                      fontSize: 13,
                    ),
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }
}