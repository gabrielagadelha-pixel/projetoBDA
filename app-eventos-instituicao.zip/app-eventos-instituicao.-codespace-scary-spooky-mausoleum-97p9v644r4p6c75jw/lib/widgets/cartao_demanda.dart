import 'package:flutter/material.dart';
import '../models/demanda.dart';
import '../telas/tela_detalhe_demanda.dart';
import '../utils/cores.dart';
import '../utils/cores_cursos.dart';
import '../utils/cursos.dart';
import '../utils/datas.dart';

class CartaoDemanda extends StatelessWidget {
  final Demanda demanda;

  const CartaoDemanda({
    super.key,
    required this.demanda,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => TelaDetalheDemanda(demanda: demanda),
          ),
        );
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: corBranca,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: corAzulClaro, width: 1.5),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    '${demanda.codigo} · ${demanda.categoria.nome}',
                    style: const TextStyle(
                      color: corTextoSecundario,
                      fontSize: 12,
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: corAzulClaro,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    demanda.status.nome,
                    style: const TextStyle(
                      color: corEscura,
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              demanda.titulo,
              style: const TextStyle(
                color: corEscura,
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Container(
                  width: 10,
                  height: 10,
                  decoration: BoxDecoration(
                    color: CoresCursos.corDoCurso(demanda.curso),
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    nomeCurto(demanda.curso),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: corTextoSecundario,
                      fontSize: 12,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  'Entrega ${formatarData(demanda.entrega)}',
                  style: const TextStyle(
                    color: corTextoSecundario,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}