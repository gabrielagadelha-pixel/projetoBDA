import 'package:flutter/material.dart';
import '../utils/cores.dart';

class CabecalhoOnda extends StatelessWidget {
  final Widget child;
  final double altura;

  const CabecalhoOnda({
    super.key,
    required this.child,
    this.altura = 140,
  });

  @override
  Widget build(BuildContext context) {
    return ClipPath(
      clipper: _OndaClipper(),
      child: Container(
        width: double.infinity,
        height: altura,
        color: corCabecalho,
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 30),
        child: SafeArea(
          bottom: false,
          child: child,
        ),
      ),
    );
  }
}

class _OndaClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final path = Path();
    path.lineTo(0, size.height - 30);
    path.quadraticBezierTo(
      size.width * 0.25,
      size.height,
      size.width * 0.6,
      size.height - 25,
    );
    path.quadraticBezierTo(
      size.width * 0.85,
      size.height - 45,
      size.width,
      size.height - 30,
    );
    path.lineTo(size.width, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}