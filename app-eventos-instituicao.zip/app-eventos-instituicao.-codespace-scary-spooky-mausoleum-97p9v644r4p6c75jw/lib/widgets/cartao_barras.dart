import 'package:flutter/material.dart';
import '../utils/cores.dart';

class ItemBarra {
  final String rotulo;
  final int valor;
  final Color cor;

  const ItemBarra({
    required this.rotulo,
    required this.valor,
    required this.cor,
  });
}

class CartaoBarras extends StatelessWidget {
  final String titulo;
  final List<ItemBarra> itens;

  const CartaoBarras({
    super.key,
    required this.titulo,
    required this.itens,
  });

  @override
  Widget build(BuildContext context) {
    int maior = 1;
    for (final item in itens) {
      if (item.valor > maior) {
        maior = item.valor;
      }
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: corBranca,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: corBotao),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            titulo,
            style: const TextStyle(
              color: corEscura,
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 12),
          ...itens.map((item) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Row(
                children: [
                  SizedBox(
                    width: 140,
                    child: Text(
                      item.rotulo,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: corEscura,
                        fontSize: 13,
                      ),
                    ),
                  ),
                  Expanded(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: LinearProgressIndicator(
                        value: item.valor / maior,
                        minHeight: 10,
                        color: item.cor,
                        backgroundColor: corAzulClaro,
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Text(
                    '${item.valor}',
                    style: const TextStyle(
                      color: corTextoSecundario,
                      fontSize: 13,
                    ),
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }
}