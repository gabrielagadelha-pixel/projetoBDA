import 'package:flutter/material.dart';
import '../models/demanda.dart';
import '../utils/cores.dart';

class CartaoAtualizarStatus extends StatefulWidget {
  final Demanda demanda;

  const CartaoAtualizarStatus({
    super.key,
    required this.demanda,
  });

  @override
  State<CartaoAtualizarStatus> createState() =>
      _CartaoAtualizarStatusState();
}

class _CartaoAtualizarStatusState extends State<CartaoAtualizarStatus> {
  late StatusDemanda _status;
  final TextEditingController _observacao = TextEditingController();

  @override
  void initState() {
    super.initState();
    _status = widget.demanda.status;
  }

  @override
  void dispose() {
    _observacao.dispose();
    super.dispose();
  }

  void _salvar() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Status "${_status.nome}" selecionado. '
          'O salvamento de verdade virá com o banco de dados.',
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: corBranca,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: corBotao),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Atualizar status (equipe de Marketing)',
            style: TextStyle(
              color: corEscura,
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<StatusDemanda>(
            value: _status,
            isExpanded: true,
            decoration: InputDecoration(
              filled: true,
              fillColor: corBranca,
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 12,
                vertical: 10,
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(color: corBotao),
              ),
            ),
            items: StatusDemanda.values.map((status) {
              return DropdownMenuItem<StatusDemanda>(
                value: status,
                child: Text(status.nome),
              );
            }).toList(),
            onChanged: (novo) {
              if (novo != null) {
                setState(() {
                  _status = novo;
                });
              }
            },
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _observacao,
            decoration: InputDecoration(
              hintText: 'Observação (opcional)',
              filled: true,
              fillColor: corBranca,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(color: corBotao),
              ),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            height: 48,
            child: ElevatedButton(
              onPressed: _salvar,
              style: ElevatedButton.styleFrom(
                backgroundColor: corBotao,
                foregroundColor: corBranca,
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: const Text(
                'Salvar status',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
    );
  }
}