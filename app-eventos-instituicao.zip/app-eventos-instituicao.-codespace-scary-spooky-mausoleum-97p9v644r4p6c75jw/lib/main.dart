import 'package:flutter/material.dart';
import 'telas/tela_boas_vindas.dart';
import 'utils/cores.dart';
import 'telas/tela_principal.dart';
import 'telas/tela_cadastro.dart';

void main() {
  runApp(const
AppEventosInstituicao());
}

class AppEventosInstituicao extends StatelessWidget {
  const
AppEventosInstituicao({super.key});

  @override 
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'FasupGup',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: corFundo,
        colorScheme: ColorScheme.fromSeed(
          seedColor: corBotao,
          brightness: Brightness.light,
        ),
      ),
      home: const TelaBoasVindas(),
    );
  }
}