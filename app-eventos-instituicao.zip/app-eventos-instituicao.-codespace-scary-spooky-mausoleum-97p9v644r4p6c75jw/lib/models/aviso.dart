enum TipoAviso {
    alerta,
    informacao,
    sucesso,
}

class Aviso {
    final String titulo;
    final String mensagem;
    final DateTime data;
    final TipoAviso tipo;
    final bool lido;

    const Aviso({
        required this.titulo,
        required this.mensagem,
        required this.data,
        required this.tipo,
        this.lido = false, 

    });
}
