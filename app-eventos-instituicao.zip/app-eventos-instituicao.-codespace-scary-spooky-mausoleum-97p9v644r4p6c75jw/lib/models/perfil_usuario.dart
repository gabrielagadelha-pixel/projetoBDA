enum PerfilUsuario {
  coordenador,
  administrador,
}

extension PerfilUsuarioExtensao on PerfilUsuario {
  String get nome {
    switch (this) {
      case PerfilUsuario.coordenador:
        return 'Coordenador';
      case PerfilUsuario.administrador:
        return 'Administrador';
    }
  }

  bool get eAdministrador {
    return this == PerfilUsuario.administrador;
  }

  bool get podeAlterarStatus => eAdministrador;

  bool get podeEditarOuExcluir => eAdministrador;

  bool get podeConfigurarCursos => eAdministrador;
}