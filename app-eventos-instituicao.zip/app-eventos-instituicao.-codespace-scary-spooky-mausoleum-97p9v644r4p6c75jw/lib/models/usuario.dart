import 'perfil_usuario.dart';

class Usuario {
  final String nome;
  final String email;
  final PerfilUsuario perfil;
  final String? curso;

  const Usuario({
    required this.nome,
    required this.email,
    required this.perfil,
    this.curso,
  });
}