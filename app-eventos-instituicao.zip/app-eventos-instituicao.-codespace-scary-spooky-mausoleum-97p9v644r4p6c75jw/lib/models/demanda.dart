enum CategoriaDemanda {
  eventos,
  redesSociais,
  materialInstitucional,
  publicacaoSite,
  endomarketing,
}

extension CategoriaDemandaExtensao on CategoriaDemanda {
  String get nome {
    switch (this) {
      case CategoriaDemanda.eventos:
        return 'Eventos';
      case CategoriaDemanda.redesSociais:
        return 'Redes Sociais';
      case CategoriaDemanda.materialInstitucional:
        return 'Material Institucional';
      case CategoriaDemanda.publicacaoSite:
        return 'Publicação no site';
      case CategoriaDemanda.endomarketing:
        return 'Endomarketing';
    }
  }
}

enum StatusDemanda {
  enviada,
  emAnalise,
  aguardando,
  aprovada,
  emProducao,
  concluida,
}

extension StatusDemandaExtensao on StatusDemanda {
  String get nome {
    switch (this) {
      case StatusDemanda.enviada:
        return 'Enviada';
      case StatusDemanda.emAnalise:
        return 'Em análise';
      case StatusDemanda.aguardando:
        return 'Aguardando';
      case StatusDemanda.aprovada:
        return 'Aprovada';
      case StatusDemanda.emProducao:
        return 'Em produção';
      case StatusDemanda.concluida:
        return 'Concluída';
    }
  }
}

enum PrioridadeDemanda {
  baixa,
  media,
  alta,
  urgente,
}

extension PrioridadeDemandaExtensao on PrioridadeDemanda {
  String get nome {
    switch (this) {
      case PrioridadeDemanda.baixa:
        return 'Baixa';
      case PrioridadeDemanda.media:
        return 'Média';
      case PrioridadeDemanda.alta:
        return 'Alta';
      case PrioridadeDemanda.urgente:
        return 'Urgente';
    }
  }
}

class EventoHistorico {
  final StatusDemanda status;
  final DateTime data;
  final String por;

  const EventoHistorico({
    required this.status,
    required this.data,
    required this.por,
  });
}

class Demanda {
  final String codigo;
  final CategoriaDemanda categoria;
  final String titulo;
  final String curso;
  final StatusDemanda status;
  final PrioridadeDemanda prioridade;
  final DateTime entrega;
  final String solicitante;
  final DateTime? solicitadaEm;
  final String briefing;
  final List<String> anexos;
  final List<EventoHistorico> historico;

  const Demanda({
    required this.codigo,
    required this.categoria,
    required this.titulo,
    required this.curso,
    required this.status,
    required this.prioridade,
    required this.entrega,
    required this.solicitante,
    this.solicitadaEm,
    this.briefing = '',
    this.anexos = const [],
    this.historico = const [],
  });
}