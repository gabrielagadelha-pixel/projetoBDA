import 'package:flutter/material.dart';
import '../utils/cores.dart';

class TelaHome extends StatelessWidget {
  const TelaHome({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: corFundo,
      appBar: AppBar(
        backgroundColor: corFundo,
        elevation: 0,
        title: const Text(
          'FasupGUP',
          style: TextStyle(
            color: corBranca,
            fontWeight: FontWeight.bold,
          ),
        ),
        iconTheme: const IconThemeData(color: corBranca),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: const BoxDecoration(
                color: corBotao,
              ),
              child: const Center(
                child: Text(
                  'FasupGUP',
                  style: TextStyle(
                    color: corBranca,
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.calendar_month),
              title: const Text('Calendário'),
              onTap: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Calendário em desenvolvimento.'),
                  ),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.event),
              title: const Text('Cadastrar evento'),
              onTap: () {
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: const Icon(Icons.school),
              title: const Text('Cadastrar palestra'),
              onTap: () {
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Olá!',
                style: TextStyle(
                  color: corBranca,
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Bem-vindo(a) ao gerenciamento de eventos.',
                style: TextStyle(
                  color: corBranca,
                  fontSize: 15,
                ),
              ),
              const SizedBox(height: 32),
              const Text(
                'Seus eventos',
                style: TextStyle(
                  color: corBranca,
                  fontSize: 21,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.event_note,
                        size: 75,
                        color: corBranca.withValues(alpha: 0.8),
                      ),
                      const SizedBox(height: 12),
                      const Text(
                        'Nenhum evento cadastrado ainda.',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: corBranca,
                          fontSize: 15,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}