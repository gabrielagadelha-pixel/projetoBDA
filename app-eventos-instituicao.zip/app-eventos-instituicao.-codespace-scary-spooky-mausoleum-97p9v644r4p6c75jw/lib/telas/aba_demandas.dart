import 'package:flutter/material.dart';
import '../models/demanda.dart';
import '../utils/cores.dart';
import '../utils/cursos.dart';
import '../utils/demanda_exemplo.dart';
import '../widgets/cabecalho_onda.dart';
import '../widgets/cartao_demanda.dart';
import '../widgets/logo_fasup.dart';

class AbaDemandas extends StatefulWidget {
  const AbaDemandas({super.key});

  @override
  State<AbaDemandas> createState() => _AbaDemandasState();
}

class _AbaDemandasState extends State<AbaDemandas> {
  CategoriaDemanda? _categoria;
  String? _curso;
  StatusDemanda? _status;

  List<Demanda> get _filtradas {
    return demandasExemplo.where((demanda) {
      if (_categoria != null && demanda.categoria != _categoria) {
        return false;
      }
      if (_curso != null && demanda.curso != _curso) {
        return false;
      }
      if (_status != null && demanda.status != _status) {
        return false;
      }
      return true;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final filtradas = _filtradas;

    return Column(
      children: [
        CabecalhoOnda(
          altura: 130,
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  color: corFundo,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const LogoFasup(tamanho: 56),
              ),
              const SizedBox(width: 14),
              const Text(
                'Demandas',
                style: TextStyle(
                  color: corBranca,
                  fontSize: 22,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 80),
            children: [
              Row(
                children: [
                  Expanded(
                    child: _filtro<CategoriaDemanda>(
                      rotulo: 'Categoria',
                      valor: _categoria,
                      opcoes: CategoriaDemanda.values,
                      nomeDe: (categoria) => categoria.nome,
                      aoMudar: (novo) {
                        setState(() {
                          _categoria = novo;
                        });
                      },
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _filtro<String>(
                      rotulo: 'Curso',
                      valor: _curso,
                      opcoes: listaCursos,
                      nomeDe: nomeCurto,
                      aoMudar: (novo) {
                        setState(() {
                          _curso = novo;
                        });
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              _filtro<StatusDemanda>(
                rotulo: 'Status',
                valor: _status,
                opcoes: StatusDemanda.values,
                nomeDe: (status) => status.nome,
                aoMudar: (novo) {
                  setState(() {
                    _status = novo;
                  });
                },
              ),
              const SizedBox(height: 16),
              if (filtradas.isEmpty)
                const Padding(
                  padding: EdgeInsets.only(top: 40),
                  child: Center(
                    child: Text(
                      'Nenhuma demanda encontrada.',
                      style: TextStyle(color: corTextoSecundario),
                    ),
                  ),
                )
              else
                ...filtradas.map(
                  (demanda) => CartaoDemanda(demanda: demanda),
                ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _filtro<T>({
    required String rotulo,
    required T? valor,
    required List<T> opcoes,
    required String Function(T) nomeDe,
    required ValueChanged<T?> aoMudar,
  }) {
    return DropdownButtonFormField<T>(
      value: valor,
      isExpanded: true,
      hint: const Text('Todos'),
      decoration: InputDecoration(
        labelText: rotulo,
        filled: true,
        fillColor: corBranca,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 12,
          vertical: 10,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: corBotao),
        ),
      ),
      items: [
        DropdownMenuItem<T>(
          value: null,
          child: const Text('Todos'),
        ),
        ...opcoes.map(
          (opcao) => DropdownMenuItem<T>(
            value: opcao,
            child: Text(
              nomeDe(opcao),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ),
      ],
      onChanged: aoMudar,
    );
  }
}