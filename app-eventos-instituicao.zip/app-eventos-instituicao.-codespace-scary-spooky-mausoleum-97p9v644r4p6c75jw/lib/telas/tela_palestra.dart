import 'package:flutter/material.dart';
import '../utils/cores.dart';

class TelaPalestra extends StatefulWidget {
  const TelaPalestra({super.key});

  @override
  State<TelaPalestra> createState() => _TelaPalestraState();
}

class _TelaPalestraState extends State<TelaPalestra> {
  final nomeController = TextEditingController();
  final temaController = TextEditingController();
  final palestranteController = TextEditingController();
  final localController = TextEditingController();

  DateTime? dataSelecionada;
  TimeOfDay? horarioSelecionado;

  final List<String> cursos = [
    'Administração',
    'Análise e Desenvolvimento de Sistemas',
    'Direito',
    'Enfermagem',
    'Pedagogia',
  ];

  final List<String> cursosSelecionados = [];

  Future<void> selecionarData() async {
    final data = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(2035),
    );

    if (data != null) {
      setState(() {
        dataSelecionada = data;
      });
    }
  }

  Future<void> selecionarHorario() async {
    final horario = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );

    if (horario != null) {
      setState(() {
        horarioSelecionado = horario;
      });
    }
  }

  void enviarPalestra() {
    if (nomeController.text.trim().isEmpty ||
        temaController.text.trim().isEmpty ||
        palestranteController.text.trim().isEmpty ||
        localController.text.trim().isEmpty ||
        dataSelecionada == null ||
        horarioSelecionado == null ||
        cursosSelecionados.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Preencha todos os campos.'),
        ),
      );
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Palestra preenchida com sucesso!'),
      ),
    );
  }

  @override
  void dispose() {
    nomeController.dispose();
    temaController.dispose();
    palestranteController.dispose();
    localController.dispose();
    super.dispose();
  }

  Widget campoTexto({
    required String titulo,
    required String dica,
    required TextEditingController controller,
    int linhas = 1,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          titulo,
          style: const TextStyle(
            color: corEscura,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: controller,
          maxLines: linhas,
          decoration: InputDecoration(
            hintText: dica,
            filled: true,
            fillColor: corBranca,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide.none,
            ),
          ),
        ),
        const SizedBox(height: 18),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: corFundo,
      appBar: AppBar(
        title: const Text(
          'Cadastrar palestra',
          style: TextStyle(
            color: corEscura,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: corFundo,
        elevation: 0,
        iconTheme: const IconThemeData(color: corEscura),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            campoTexto(
              titulo: 'Nome da palestra',
              dica: 'Digite o título da palestra',
              controller: nomeController,
            ),
            campoTexto(
              titulo: 'Tema ou descrição',
              dica: 'Descreva o assunto da palestra',
              controller: temaController,
              linhas: 3,
            ),
            campoTexto(
              titulo: 'Palestrante',
              dica: 'Nome do palestrante',
              controller: palestranteController,
            ),
            campoTexto(
              titulo: 'Local',
              dica: 'Onde acontecerá a palestra?',
              controller: localController,
            ),

            const Text(
              'Data da palestra',
              style: TextStyle(
                color: corEscura,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: selecionarData,
                icon: const Icon(Icons.calendar_month),
                label: Text(
                  dataSelecionada == null
                      ? 'Selecionar data'
                      : '${dataSelecionada!.day}/${dataSelecionada!.month}/${dataSelecionada!.year}',
                ),
              ),
            ),

            const SizedBox(height: 18),

            const Text(
              'Horário',
              style: TextStyle(
                color: corEscura,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: selecionarHorario,
                icon: const Icon(Icons.access_time),
                label: Text(
                  horarioSelecionado == null
                      ? 'Selecionar horário'
                      : horarioSelecionado!.format(context),
                ),
              ),
            ),

            const SizedBox(height: 22),

            const Text(
              'Cursos envolvidos',
              style: TextStyle(
                color: corEscura,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),

            Wrap(
              spacing: 8,
              children: cursos.map((curso) {
                final selecionado =
                    cursosSelecionados.contains(curso);

                return FilterChip(
                  label: Text(curso),
                  selected: selecionado,
                  selectedColor: corBotao,
                  checkmarkColor: corBranca,
                  labelStyle: TextStyle(
                    color: selecionado ? corBranca : corEscura,
                  ),
                  onSelected: (valor) {
                    setState(() {
                      if (valor) {
                        cursosSelecionados.add(curso);
                      } else {
                        cursosSelecionados.remove(curso);
                      }
                    });
                  },
                );
              }).toList(),
            ),

            const SizedBox(height: 30),

            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: enviarPalestra,
                style: ElevatedButton.styleFrom(
                  backgroundColor: corBotao,
                  foregroundColor: corBranca,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: const Text(
                  'Enviar palestra',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}