import 'package:flutter/material.dart';
import '../utils/cores.dart';
import '../widgets/logo_fasup.dart';
import 'tela_login.dart';
import 'tela_cadastro.dart';

class TelaBoasVindas extends StatelessWidget {
  const TelaBoasVindas({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: corFundo,
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            final tamanhoLogo =
                (constraints.maxWidth * 0.55).clamp(150.0, 220.0);

            return SingleChildScrollView(
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  minHeight: constraints.maxHeight,
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 28,
                    vertical: 24,
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      // IDENTIDADE VISUAL
                      Column(
                        children: [
                          Align(
                            alignment: Alignment.topRight,
                            child: Container(
                              width: 48,
                              height: 6,
                              decoration: BoxDecoration(
                                color: corDestaque,
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                          ),

                          const SizedBox(height: 65),

                          LogoFasup(tamanho: tamanhoLogo),

                          const SizedBox(height: 38),

                          Container(
                            width: 55,
                            height: 5,
                            decoration: BoxDecoration(
                              color: corDestaque,
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),

                          const SizedBox(height: 22),

                          const Text(
                            'Bem-vindo ao FasupGUP',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 25,
                              fontWeight: FontWeight.bold,
                              color: corEscura,
                            ),
                          ),

                          const SizedBox(height: 12),

                          const Text(
                            'Solicite materiais e acompanhe suas'
                            'demandas com o Marketing',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 15,
                              height: 1.5,
                              color: corTextoSecundario,
                            ),
                          ),
                        ],
                      ),

                      // BOTÕES
                      Padding(
                        padding: const EdgeInsets.only(
                          top: 55,
                          bottom: 18,
                        ),
                        child: Column(
                          children: [
                            SizedBox(
                              width: double.infinity,
                              height: 54,
                              child: ElevatedButton(
                                onPressed: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) =>
                                          const TelaLogin(),
                                    ),
                                  );
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: corBotao,
                                  foregroundColor: corBranca,
                                  elevation: 0,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                ),
                                child: const Text(
                                  'Fazer login',
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),

                            const SizedBox(height: 14),

                            SizedBox(
                              width: double.infinity,
                              height: 54,
                              child: OutlinedButton(
                                onPressed: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) =>
                                          const TelaCadastro(),
                                    ),
                                  );
                                },
                                style: OutlinedButton.styleFrom(
                                  foregroundColor: corEscura,
                                  side: const BorderSide(
                                    color: corBotao,
                                    width: 1.5,
                                  ),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                ),
                                child: const Text(
                                  'Criar conta',
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),

                            const SizedBox(height: 24),

                            const Text(
                              'FASUP • Setor de Marketing',
                              style: TextStyle(
                                fontSize: 12,
                                color: corTextoSecundario,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}