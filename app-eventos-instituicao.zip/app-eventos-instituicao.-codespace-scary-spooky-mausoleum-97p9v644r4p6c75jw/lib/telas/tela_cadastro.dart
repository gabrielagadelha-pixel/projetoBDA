import 'package:flutter/material.dart';
import '../utils/cores.dart';
import '../models/perfil_usuario.dart';
import '../utils/cursos.dart';
import '../widgets/logo_fasup.dart';

class TelaCadastro extends StatefulWidget {
  const TelaCadastro({super.key});

  @override
  State<TelaCadastro> createState() => _TelaCadastroState();
}

class _TelaCadastroState extends State<TelaCadastro> {
  final nomeController = TextEditingController();
  final emailController = TextEditingController();
  final senhaController = TextEditingController();
  final confirmarSenhaController = TextEditingController();

  bool ocultarSenha = true;

  final PerfilUsuario perfilSelecionado = PerfilUsuario.coordenador;
  String? cursoSelecionado;

  @override
  void dispose() {
    nomeController.dispose();
    emailController.dispose();
    senhaController.dispose();
    confirmarSenhaController.dispose();
    super.dispose();
  }

  void cadastrar() {
    if (nomeController.text.isEmpty ||
        emailController.text.isEmpty ||
        senhaController.text.isEmpty ||
        confirmarSenhaController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Preencha todos os campos.'),
        ),
      );
      return;
    }

    if (cursoSelecionado == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Selecione o seu curso.'),
        ),
      );
      return;
    }

    if (senhaController.text != confirmarSenhaController.text) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('As senhas não coincidem.'),
        ),
      );
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Cadastro preenchido como ${perfilSelecionado.nome} de $cursoSelecionado!',
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: corFundo,
      appBar: AppBar(
        backgroundColor: corFundo,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(28),
          child: Column(
            children: [
              const LogoFasup(tamanho: 200),

              const SizedBox(height: 24),

              const Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Crie sua conta',
                  style: TextStyle(
                    fontSize: 24,
                    color: corEscura,
                  ),
                ),
              ),

              const SizedBox(height: 20),

              campoTexto(
                controller: nomeController,
                texto: 'Nome completo',
                icone: Icons.person_outline,
              ),

              const SizedBox(height: 15),

              campoTexto(
                controller: emailController,
                texto: 'E-mail institucional',
                icone: Icons.email_outlined,
                tipo: TextInputType.emailAddress,
              ),

              const SizedBox(height: 15),

              DropdownButtonFormField<String>(
                value: cursoSelecionado,
                isExpanded: true,
                decoration: InputDecoration(
                  labelText: 'Curso',
                  prefixIcon: const Icon(
                    Icons.school_outlined,
                    color: corEscura,
                  ),
                  filled: true,
                  fillColor: corBranca,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                ),
                hint: const Text('Selecione seu curso'),
                items: listaCursos.map((curso) {
                  return DropdownMenuItem<String>(
                    value: curso,
                    child: Text(
                      curso,
                      overflow: TextOverflow.ellipsis,
                    ),
                  );
                }).toList(),
                onChanged: (String? novoCurso) {
                  setState(() {
                    cursoSelecionado = novoCurso;
                  });
                },
              ),

              const SizedBox(height: 15),

              campoTexto(
                controller: senhaController,
                texto: 'Senha',
                icone: Icons.lock_outline,
                senha: true,
              ),

              const SizedBox(height: 15),

              campoTexto(
                controller: confirmarSenhaController,
                texto: 'Confirmar senha',
                icone: Icons.lock_outline,
                senha: true,
              ),

              const SizedBox(height: 25),

              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: cadastrar,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: corBotao,
                    foregroundColor: corBranca,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: const Text(
                    'CADASTRAR',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget campoTexto({
    required TextEditingController controller,
    required String texto,
    required IconData icone,
    TextInputType tipo = TextInputType.text,
    bool senha = false,
  }) {
    return TextField(
      controller: controller,
      keyboardType: tipo,
      obscureText: senha && ocultarSenha,
      decoration: InputDecoration(
        labelText: texto,
        prefixIcon: Icon(icone, color: corEscura),
        suffixIcon: senha
            ? IconButton(
                icon: Icon(
                  ocultarSenha
                      ? Icons.visibility_off
                      : Icons.visibility,
                ),
                onPressed: () {
                  setState(() {
                    ocultarSenha = !ocultarSenha;
                  });
                },
              )
            : null,
        filled: true,
        fillColor: corBranca,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }
}