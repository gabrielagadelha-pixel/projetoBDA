import 'package:flutter/material.dart';
import '../models/perfil_usuario.dart';
import '../utils/cores.dart';
import '../utils/sessao.dart';
import 'aba_agenda.dart';
import 'aba_avisos.dart';
import 'aba_demandas.dart';
import 'aba_inicio.dart';
import 'tela_boas_vindas.dart';
import 'tela_perfil.dart';

class TelaPrincipal extends StatefulWidget {
  const TelaPrincipal({super.key});

  @override
  State<TelaPrincipal> createState() => _TelaPrincipalState();
}

class _TelaPrincipalState extends State<TelaPrincipal> {
  int _indiceAtual = 0;

  final List<Widget> _paginas = const [
    AbaInicio(),
    AbaAgenda(),
    AbaDemandas(),
    AbaAvisos(),
  ];

  void _abrirPerfil() {
    Navigator.pop(context);
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const TelaPerfil(),
      ),
    );
  }

  void _abrirConfiguracoes() {
    Navigator.pop(context);
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Configurações'),
          content: const Text(
            'As configurações do aplicativo serão implementadas '
            'nesta área.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Fechar'),
            ),
          ],
        );
      },
    );
  }

  void _sair() {
    Sessao.sair();
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(
        builder: (context) => const TelaBoasVindas(),
      ),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    final usuario = Sessao.usuarioAtual;
    final nome = usuario?.nome ?? 'Visitante';
    final perfil = usuario?.perfil.nome ?? '';
    final inicial = nome.isEmpty ? '?' : nome[0].toUpperCase();

    return Scaffold(
      drawer: Drawer(
        backgroundColor: corBranca,
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: const BoxDecoration(color: corCabecalho),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircleAvatar(
                    radius: 30,
                    backgroundColor: corBranca,
                    child: Text(
                      inicial,
                      style: const TextStyle(
                        color: corCabecalho,
                        fontSize: 26,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    nome,
                    style: const TextStyle(
                      color: corBranca,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    perfil,
                    style: TextStyle(
                      color: corBranca.withValues(alpha: 0.9),
                    ),
                  ),
                ],
              ),
            ),
            ListTile(
              leading: const Icon(Icons.person_outline, color: corEscura),
              title: const Text('Meu perfil'),
              onTap: _abrirPerfil,
            ),
            ListTile(
              leading: const Icon(Icons.settings_outlined, color: corEscura),
              title: const Text('Configurações'),
              onTap: _abrirConfiguracoes,
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.logout, color: corEscura),
              title: const Text('Sair'),
              onTap: _sair,
            ),
          ],
        ),
      ),
      body: _paginas[_indiceAtual],
      floatingActionButton: FloatingActionButton(
        onPressed: () {},
        backgroundColor: corEscura,
        foregroundColor: corDestaque,
        shape: const CircleBorder(),
        child: const Icon(Icons.add, size: 32),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _indiceAtual,
        onTap: (indice) {
          setState(() {
            _indiceAtual = indice;
          });
        },
        type: BottomNavigationBarType.fixed,
        selectedItemColor: corBotao,
        unselectedItemColor: corTextoSecundario,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home_outlined),
            label: 'Início',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.calendar_today_outlined),
            label: 'Agenda',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.bar_chart_outlined),
            label: 'Demandas',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.notifications_none),
            label: 'Avisos',
          ),
        ],
      ),
    );
  }
}