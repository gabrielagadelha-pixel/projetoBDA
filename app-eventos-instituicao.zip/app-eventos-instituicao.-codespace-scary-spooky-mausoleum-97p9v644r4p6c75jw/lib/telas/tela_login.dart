import 'package:flutter/material.dart';
import '../models/perfil_usuario.dart';
import '../models/usuario.dart';
import '../utils/cores.dart';
import '../utils/sessao.dart';
import '../widgets/logo_fasup.dart';
import 'tela_principal.dart';

class TelaLogin extends StatefulWidget {
  const TelaLogin({super.key});

  @override
  State<TelaLogin> createState() => _TelaLoginState();
}

class _TelaLoginState extends State<TelaLogin> {
  final TextEditingController emailController =
      TextEditingController();
  final TextEditingController senhaController =
      TextEditingController();

  bool mostrarSenha = false;

  @override
  void dispose() {
    emailController.dispose();
    senhaController.dispose();
    super.dispose();
  }

  void entrar() {
    final email = emailController.text.trim();
    final senha = senhaController.text;

    if (email.isEmpty || senha.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Preencha o e-mail e a senha.'),
        ),
      );
      return;
    }

    final eAdmin = email.toLowerCase().startsWith('admin');

    final usuario = eAdmin
        ? Usuario(
            nome: 'Administrador',
            email: email,
            perfil: PerfilUsuario.administrador,
          )
        : Usuario(
            nome: email.split('@').first,
            email: email,
            perfil: PerfilUsuario.coordenador,
            curso: 'Análise e Desenvolvimento de Sistemas - Tecnólogo',
          );

    Sessao.entrar(usuario);

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => const TelaPrincipal(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: corFundo,
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            return SingleChildScrollView(
              padding: const EdgeInsets.symmetric(
                horizontal: 28,
                vertical: 24,
              ),
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  minHeight: constraints.maxHeight - 48,
                ),
                child: IntrinsicHeight(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const SizedBox(height: 20),

                      const Center(
                        child: LogoFasup(tamanho: 180),
                      ),

                      const SizedBox(height: 30),

                      const Text(
                        'Bem-vindo(a)!',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: corEscura,
                          fontSize: 27,
                          fontWeight: FontWeight.bold,
                        ),
                      ),

                      const SizedBox(height: 8),

                      const Text(
                        'Entre na sua conta FasupGUP.',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: corTextoSecundario,
                          fontSize: 14,
                        ),
                      ),

                      const SizedBox(height: 38),

                      const Text(
                        'E-mail institucional',
                        style: TextStyle(
                          color: corEscura,
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                      ),

                      const SizedBox(height: 8),

                      TextField(
                        controller: emailController,
                        keyboardType: TextInputType.emailAddress,
                        textInputAction: TextInputAction.next,
                        decoration: InputDecoration(
                          hintText: 'Digite seu e-mail',
                          prefixIcon: const Icon(
                            Icons.email_outlined,
                            color: corTextoSecundario,
                          ),
                          filled: true,
                          fillColor: corBranca,
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 14,
                            vertical: 16,
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide.none,
                          ),
                        ),
                      ),

                      const SizedBox(height: 22),

                      const Text(
                        'Senha',
                        style: TextStyle(
                          color: corEscura,
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                      ),

                      const SizedBox(height: 8),

                      TextField(
                        controller: senhaController,
                        obscureText: !mostrarSenha,
                        textInputAction: TextInputAction.done,
                        onSubmitted: (_) => entrar(),
                        decoration: InputDecoration(
                          hintText: 'Digite sua senha',
                          prefixIcon: const Icon(
                            Icons.lock_outline,
                            color: corTextoSecundario,
                          ),
                          suffixIcon: IconButton(
                            tooltip: mostrarSenha
                                ? 'Ocultar senha'
                                : 'Mostrar senha',
                            onPressed: () {
                              setState(() {
                                mostrarSenha = !mostrarSenha;
                              });
                            },
                            icon: Icon(
                              mostrarSenha
                                  ? Icons.visibility_off
                                  : Icons.visibility,
                              color: corTextoSecundario,
                            ),
                          ),
                          filled: true,
                          fillColor: corBranca,
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 14,
                            vertical: 16,
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide.none,
                          ),
                        ),
                      ),

                      Align(
                        alignment: Alignment.centerRight,
                        child: TextButton(
                          onPressed: () {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text(
                                  'A recuperação de senha será implementada.',
                                ),
                              ),
                            );
                          },
                          child: const Text(
                            'Esqueceu a senha?',
                            style: TextStyle(
                              color: corBotao,
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(height: 18),

                      SizedBox(
                        height: 52,
                        child: ElevatedButton(
                          onPressed: entrar,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: corBotao,
                            foregroundColor: corBranca,
                            elevation: 0,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          child: const Text(
                            'Entrar',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(height: 28),

                      const Center(
                        child: Text(
                          'FASUP • Setor de Marketing',
                          style: TextStyle(
                            color: corTextoSecundario,
                            fontSize: 12,
                          ),
                        ),
                      ),

                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}