import 'package:flutter/material.dart';
import '../models/demanda.dart';
import '../utils/cores.dart';
import '../utils/cores_cursos.dart';
import '../utils/cursos.dart';
import '../utils/datas.dart';
import '../widgets/cabecalho_onda.dart';
import '../models/perfil_usuario.dart';
import '../utils/sessao.dart';
import '../widgets/cartao_atualizar_status.dart';

class TelaDetalheDemanda extends StatelessWidget {
  final Demanda demanda;

  const TelaDetalheDemanda({
    super.key,
    required this.demanda,
  });

  @override
  Widget build(BuildContext context) {
    final solicitada = demanda.solicitadaEm;
    final podeAlterar = Sessao.usuarioAtual?.perfil.podeAlterarStatus ?? false;

    return Scaffold(
      backgroundColor: corFundo,
      body: Column(
        children: [
          CabecalhoOnda(
            altura: 130,
            child: Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.arrow_back, color: corBranca),
                  onPressed: () => Navigator.pop(context),
                ),
                const SizedBox(width: 8),
                const Text(
                  'Demandas',
                  style: TextStyle(
                    color: corBranca,
                    fontSize: 22,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: [
                _cartao(
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          _etiqueta(demanda.status.nome),
                          _etiqueta('Prioridade ${demanda.prioridade.nome}'),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Text(
                        demanda.titulo,
                        style: const TextStyle(
                          color: corEscura,
                          fontSize: 20,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        '${demanda.categoria.nome} · ${demanda.solicitante}',
                        style: const TextStyle(
                          color: corTextoSecundario,
                          fontSize: 14,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Container(
                            width: 10,
                            height: 10,
                            decoration: BoxDecoration(
                              color: CoresCursos.corDoCurso(demanda.curso),
                              shape: BoxShape.circle,
                            ),
                          ),
                          const SizedBox(width: 6),
                          Expanded(
                            child: Text(
                              nomeCurto(demanda.curso),
                              style: const TextStyle(
                                color: corTextoSecundario,
                                fontSize: 14,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      Row(
                        children: [
                          Expanded(
                            child: _caixaData(
                              'Solicitada em',
                              solicitada == null
                                  ? '—'
                                  : formatarData(solicitada),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: _caixaData(
                              'Entrega',
                              formatarData(demanda.entrega),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
                _cartao(
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _titulo('Briefing'),
                      const SizedBox(height: 8),
                      Text(
                        demanda.briefing.isEmpty
                            ? 'Sem briefing.'
                            : demanda.briefing,
                        style: const TextStyle(
                          color: corEscura,
                          fontSize: 14,
                        ),
                      ),
                      const SizedBox(height: 16),
                      _titulo('Anexos'),
                      const SizedBox(height: 8),
                      if (demanda.anexos.isEmpty)
                        const Text(
                          'Sem anexos.',
                          style: TextStyle(
                            color: corTextoSecundario,
                            fontSize: 13,
                          ),
                        )
                      else
                        ...demanda.anexos.map((nome) => _linhaAnexo(nome)),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
                if (podeAlterar) ...[
                  CartaoAtualizarStatus(demanda: demanda),
                  const SizedBox(height: 14),
                ],
                _cartao(
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _titulo('Histórico'),
                      const SizedBox(height: 12),
                      if (demanda.historico.isEmpty)
                        const Text(
                          'Sem histórico.',
                          style: TextStyle(
                            color: corTextoSecundario,
                            fontSize: 13,
                          ),
                        )
                      else
                        ...demanda.historico.map(
                          (evento) => _linhaHistorico(evento),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _cartao(Widget conteudo) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: corBranca,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: corBotao),
      ),
      child: conteudo,
    );
  }

  Widget _titulo(String texto) {
    return Text(
      texto,
      style: const TextStyle(
        color: corEscura,
        fontSize: 16,
        fontWeight: FontWeight.w600,
      ),
    );
  }

  Widget _etiqueta(String texto) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: corAzulClaro,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        texto,
        style: const TextStyle(
          color: corEscura,
          fontSize: 12,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Widget _caixaData(String rotulo, String data) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: corAzulClaro,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            rotulo,
            style: const TextStyle(
              color: corTextoSecundario,
              fontSize: 12,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            data,
            style: const TextStyle(
              color: corEscura,
              fontSize: 14,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _linhaAnexo(String nome) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: corAzulClaro,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          const Icon(Icons.attach_file, size: 18, color: corEscura),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              nome,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: corEscura, fontSize: 13),
            ),
          ),
        ],
      ),
    );
  }

  Widget _linhaHistorico(EventoHistorico evento) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Container(
              width: 10,
              height: 10,
              decoration: const BoxDecoration(
                color: corCabecalho,
                shape: BoxShape.circle,
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${evento.status.nome} · ${formatarData(evento.data)}',
                  style: const TextStyle(
                    color: corEscura,
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Text(
                  'por ${evento.por}',
                  style: const TextStyle(
                    color: corTextoSecundario,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}