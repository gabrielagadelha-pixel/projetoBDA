import 'package:flutter/material.dart';
import '../models/demanda.dart';
import '../utils/cores.dart';
import '../utils/cores_cursos.dart';
import '../utils/cursos.dart';
import '../utils/demanda_exemplo.dart';
import '../widgets/cabecalho_onda.dart';
import '../widgets/cartao_barras.dart';


class TelaRelatorios extends StatelessWidget {
  const TelaRelatorios({super.key});

  Widget _numero(String rotulo, int valor, Color cor) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: corBranca,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: corBotao),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '$valor',
            style: TextStyle(
              color: cor,
              fontSize: 28,
              fontWeight: FontWeight.w600,
            ),
          ),
          Text(
            rotulo,
            style: const TextStyle(
              color: corTextoSecundario,
              fontSize: 13,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final demandas = demandasExemplo;
    final hoje = DateTime.now();

    final total = demandas.length;
    final concluidas = demandas
        .where((d) => d.status == StatusDemanda.concluida)
        .length;
    final pendentes = total - concluidas;
    final atrasadas = demandas
        .where(
          (d) =>
              d.status != StatusDemanda.concluida &&
              d.entrega.isBefore(hoje),
        )
        .length;

    final porCategoria = CategoriaDemanda.values.map((categoria) {
      return ItemBarra(
        rotulo: categoria.nome,
        valor: demandas.where((d) => d.categoria == categoria).length,
        cor: corCabecalho,
      );
    }).toList();

    final porCurso = listaCursos
        .map((curso) {
          return ItemBarra(
            rotulo: nomeCurto(curso),
            valor: demandas.where((d) => d.curso == curso).length,
            cor: CoresCursos.corDoCurso(curso),
          );
        })
        .where((item) => item.valor > 0)
        .toList();

    const meses = [
      'jan.', 'fev.', 'mar.', 'abr.', 'maio', 'jun.',
      'jul.', 'ago.', 'set.', 'out.', 'nov.', 'dez.',
    ];

    final porPeriodo = List.generate(4, (i) {
      final mes = DateTime(hoje.year, hoje.month - (3 - i));
      final quantidade = demandas.where((d) {
        final solicitada = d.solicitadaEm;
        return solicitada != null &&
            solicitada.year == mes.year &&
            solicitada.month == mes.month;
      }).length;
      return ItemBarra(
        rotulo: '${meses[mes.month - 1]} de ${mes.year % 100}',
        valor: quantidade,
        cor: corCabecalho,
      );
    });

    return Scaffold(
      backgroundColor: corFundo,
      body: Column(
        children: [
          CabecalhoOnda(
            altura: 130,
            child: Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.arrow_back, color: corBranca),
                  onPressed: () => Navigator.pop(context),
                ),
                const SizedBox(width: 8),
                const Text(
                  'Relatórios',
                  style: TextStyle(
                    color: corBranca,
                    fontSize: 22,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: [
                Row(
                  children: [
                    Expanded(child: _numero('Total', total, corCabecalho)),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _numero(
                        'Concluídas',
                        concluidas,
                        const Color(0xFF2E9E5B),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(child: _numero('Pendentes', pendentes, corEscura)),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _numero(
                        'Atrasadas',
                        atrasadas,
                        const Color(0xFFE53935),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                CartaoBarras(titulo: 'Por categoria', itens: porCategoria),
                const SizedBox(height: 14),
                CartaoBarras(titulo: 'Por curso', itens: porCurso),
                const SizedBox(height: 14),
                CartaoBarras(
                  titulo: 'Por período (mês de solicitação)',
                  itens: porPeriodo,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}