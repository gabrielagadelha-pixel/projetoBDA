import 'package:flutter/material.dart';
import '../models/aviso.dart';
import '../utils/avisos_exemplo.dart';
import '../utils/cores.dart';
import '../utils/datas.dart';
import '../widgets/cabecalho_onda.dart';
import '../widgets/logo_fasup.dart';

class AbaAvisos extends StatelessWidget {
  const AbaAvisos({super.key});

  IconData _icone(TipoAviso tipo) {
    switch (tipo) {
      case TipoAviso.alerta:
        return Icons.warning_amber_rounded;
      case TipoAviso.informacao:
        return Icons.info_outline;
      case TipoAviso.sucesso:
        return Icons.check_circle_outline;
    }
  }

  Color _cor(TipoAviso tipo) {
    switch (tipo) {
      case TipoAviso.alerta:
        return const Color(0xFFE53935);
      case TipoAviso.informacao:
        return corBotao;
      case TipoAviso.sucesso:
        return const Color(0xFF2E9E5B);
    }
  }

  Widget _cartao(Aviso aviso) {
    final cor = _cor(aviso.tipo);

    return Opacity(
      opacity: aviso.lido ? 0.55 : 1,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: corBranca,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: corAzulClaro, width: 1.5),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: cor.withValues(alpha: 0.15),
                shape: BoxShape.circle,
              ),
              child: Icon(_icone(aviso.tipo), color: cor),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Flexible(
                        child: Text(
                          aviso.titulo,
                          style: const TextStyle(
                            color: corEscura,
                            fontSize: 15,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      if (!aviso.lido)
                        Container(
                          width: 8,
                          height: 8,
                          margin: const EdgeInsets.only(left: 6),
                          decoration: const BoxDecoration(
                            color: corCabecalho,
                            shape: BoxShape.circle,
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    aviso.mensagem,
                    style: const TextStyle(
                      color: corTextoSecundario,
                      fontSize: 13,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    formatarData(aviso.data),
                    style: const TextStyle(
                      color: corTextoSecundario,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        CabecalhoOnda(
          altura: 130,
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  color: corFundo,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const LogoFasup(tamanho: 56),
              ),
              const SizedBox(width: 14),
              const Text(
                'Avisos',
                style: TextStyle(
                  color: corBranca,
                  fontSize: 22,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 80),
            children: avisosExemplo.map((aviso) => _cartao(aviso)).toList(),
          ),
        ),
      ],
    );
  }
}