import 'package:flutter/material.dart';
import '../models/demanda.dart';
import '../utils/cores.dart';
import '../utils/cores_cursos.dart';
import '../utils/demanda_exemplo.dart';
import '../widgets/cabecalho_onda.dart';
import '../widgets/cartao_demanda.dart';
import '../widgets/logo_fasup.dart';

class AbaAgenda extends StatefulWidget {
  const AbaAgenda({super.key});

  @override
  State<AbaAgenda> createState() => _AbaAgendaState();
}

class _AbaAgendaState extends State<AbaAgenda> {
  DateTime mesAtual = DateTime.now();
  DateTime diaSelecionado = DateTime.now();

  final List<String> diasSemana = [
    'Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb',
  ];

  void mudarMes(int quantidade) {
    setState(() {
      mesAtual = DateTime(
        mesAtual.year,
        mesAtual.month + quantidade,
      );
    });
  }

  bool mesmoDia(DateTime a, DateTime b) {
    return a.year == b.year &&
        a.month == b.month &&
        a.day == b.day;
  }

  String nomeMes(int mes) {
    const meses = [
      'Janeiro', 'Fevereiro', 'Março', 'Abril',
      'Maio', 'Junho', 'Julho', 'Agosto',
      'Setembro', 'Outubro', 'Novembro', 'Dezembro',
    ];

    return meses[mes - 1];
  }

  List<Demanda> demandasDoDia(DateTime dia) {
    return demandasExemplo
        .where((demanda) => mesmoDia(demanda.entrega, dia))
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    final primeiroDia = DateTime(mesAtual.year, mesAtual.month, 1);
    final quantidadeDias =
        DateTime(mesAtual.year, mesAtual.month + 1, 0).day;
    final espacosVazios = primeiroDia.weekday % 7;
    final doDia = demandasDoDia(diaSelecionado);

    return Column(
      children: [
        CabecalhoOnda(
          altura: 130,
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  color: corFundo,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const LogoFasup(tamanho: 56),
              ),
              const SizedBox(width: 14),
              const Text(
                'Agenda',
                style: TextStyle(
                  color: corBranca,
                  fontSize: 22,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 80),
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: corBranca,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: corBotao),
                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        IconButton(
                          onPressed: () => mudarMes(-1),
                          icon: const Icon(
                            Icons.chevron_left,
                            color: corEscura,
                          ),
                        ),
                        Text(
                          '${nomeMes(mesAtual.month)} ${mesAtual.year}',
                          style: const TextStyle(
                            fontSize: 19,
                            fontWeight: FontWeight.bold,
                            color: corEscura,
                          ),
                        ),
                        IconButton(
                          onPressed: () => mudarMes(1),
                          icon: const Icon(
                            Icons.chevron_right,
                            color: corEscura,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 15),
                    Row(
                      children: diasSemana.map((dia) {
                        return Expanded(
                          child: Center(
                            child: Text(
                              dia,
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                color: corEscura,
                                fontSize: 12,
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                    const SizedBox(height: 12),
                    GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: 42,
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 7,
                        childAspectRatio: 0.85,
                      ),
                      itemBuilder: (context, index) {
                        final dia = index - espacosVazios + 1;

                        if (dia < 1 || dia > quantidadeDias) {
                          return const SizedBox();
                        }

                        final data = DateTime(
                          mesAtual.year,
                          mesAtual.month,
                          dia,
                        );

                        final selecionado = mesmoDia(data, diaSelecionado);
                        final hoje = mesmoDia(data, DateTime.now());
                        final demandasDia = demandasDoDia(data);

                        return GestureDetector(
                          onTap: () {
                            setState(() {
                              diaSelecionado = data;
                            });
                          },
                          child: Container(
                            margin: const EdgeInsets.all(3),
                            decoration: BoxDecoration(
                              color: selecionado
                                  ? corBotao
                                  : Colors.transparent,
                              borderRadius: BorderRadius.circular(10),
                              border: hoje && !selecionado
                                  ? Border.all(color: corBotao, width: 1.5)
                                  : null,
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  '$dia',
                                  style: TextStyle(
                                    color:
                                        selecionado ? corBranca : corEscura,
                                    fontWeight: selecionado || hoje
                                        ? FontWeight.bold
                                        : FontWeight.normal,
                                  ),
                                ),
                                if (demandasDia.isNotEmpty)
                                  Padding(
                                    padding: const EdgeInsets.only(top: 3),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: demandasDia.take(3).map((d) {
                                        return Container(
                                          width: 6,
                                          height: 6,
                                          margin: const EdgeInsets.symmetric(
                                            horizontal: 1,
                                          ),
                                          decoration: BoxDecoration(
                                            color: selecionado
                                                ? corBranca
                                                : CoresCursos.corDoCurso(
                                                    d.curso,
                                                  ),
                                            shape: BoxShape.circle,
                                          ),
                                        );
                                      }).toList(),
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              const Text(
                'Neste dia',
                style: TextStyle(
                  color: corEscura,
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 12),
              if (doDia.isEmpty)
                const Text(
                  'Nada agendado.',
                  style: TextStyle(color: corTextoSecundario),
                )
              else
                ...doDia.map((demanda) => CartaoDemanda(demanda: demanda)),
            ],
          ),
        ),
      ],
    );
  }
}