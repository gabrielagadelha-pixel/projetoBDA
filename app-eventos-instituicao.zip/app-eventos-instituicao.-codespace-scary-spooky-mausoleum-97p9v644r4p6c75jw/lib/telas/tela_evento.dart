import 'package:flutter/material.dart';
import '../utils/cores.dart';

class TelaEvento extends StatefulWidget {
  const TelaEvento({super.key});

  @override
  State<TelaEvento> createState() => _TelaEventoState();
}

class _TelaEventoState extends State<TelaEvento> {
  final nomeController = TextEditingController();
  final descricaoController = TextEditingController();
  final localController = TextEditingController();

  DateTime? dataSelecionada;
  TimeOfDay? horarioSelecionado;

  final List<String> cursos = [
    'Administração',
    'Análise e Desenvolvimento de Sistemas',
    'Direito',
    'Enfermagem',
    'Pedagogia',
  ];

  final List<String> cursosSelecionados = [];

  Future<void> selecionarData() async {
    final data = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(2035),
    );

    if (data != null) {
      setState(() {
        dataSelecionada = data;
      });
    }
  }

  Future<void> selecionarHorario() async {
    final horario = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );

    if (horario != null) {
      setState(() {
        horarioSelecionado = horario;
      });
    }
  }

  void enviarEvento() {
    if (nomeController.text.trim().isEmpty ||
        descricaoController.text.trim().isEmpty ||
        localController.text.trim().isEmpty ||
        dataSelecionada == null ||
        horarioSelecionado == null ||
        cursosSelecionados.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Preencha todos os campos.'),
        ),
      );
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Evento preenchido com sucesso!'),
      ),
    );
  }

  @override
  void dispose() {
    nomeController.dispose();
    descricaoController.dispose();
    localController.dispose();
    super.dispose();
  }

  Widget campoTexto({
    required String titulo,
    required String dica,
    required TextEditingController controller,
    int linhas = 1,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          titulo,
          style: const TextStyle(
            color: corEscura,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: controller,
          maxLines: linhas,
          decoration: InputDecoration(
            hintText: dica,
            filled: true,
            fillColor: corBranca,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide.none,
            ),
          ),
        ),
        const SizedBox(height: 18),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: corFundo,
      appBar: AppBar(
        title: const Text(
          'Cadastrar evento',
          style: TextStyle(
            color: corEscura,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: corFundo,
        elevation: 0,
        iconTheme: const IconThemeData(color: corEscura),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            campoTexto(
              titulo: 'Nome do evento',
              dica: 'Digite o nome do evento',
              controller: nomeController,
            ),

            campoTexto(
              titulo: 'Descrição',
              dica: 'Descreva o evento',
              controller: descricaoController,
              linhas: 4,
            ),

            campoTexto(
              titulo: 'Local',
              dica: 'Onde acontecerá o evento?',
              controller: localController,
            ),

            const Text(
              'Data do evento',
              style: TextStyle(
                color: corEscura,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),

            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: selecionarData,
                icon: const Icon(Icons.calendar_month),
                label: Text(
                  dataSelecionada == null
                      ? 'Selecionar data'
                      : '${dataSelecionada!.day}/${dataSelecionada!.month}/${dataSelecionada!.year}',
                ),
              ),
            ),

            const SizedBox(height: 18),

            const Text(
              'Horário',
              style: TextStyle(
                color: corEscura,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),

            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: selecionarHorario,
                icon: const Icon(Icons.access_time),
                label: Text(
                  horarioSelecionado == null
                      ? 'Selecionar horário'
                      : horarioSelecionado!.format(context),
                ),
              ),
            ),

            const SizedBox(height: 22),

            const Text(
              'Cursos envolvidos',
              style: TextStyle(
                color: corEscura,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),

            Wrap(
              spacing: 8,
              children: cursos.map((curso) {
                final selecionado =
                    cursosSelecionados.contains(curso);

                return FilterChip(
                  label: Text(curso),
                  selected: selecionado,
                  selectedColor: corBotao,
                  checkmarkColor: corBranca,
                  labelStyle: TextStyle(
                    color: selecionado ? corBranca : corEscura,
                  ),
                  onSelected: (valor) {
                    setState(() {
                      if (valor) {
                        cursosSelecionados.add(curso);
                      } else {
                        cursosSelecionados.remove(curso);
                      }
                    });
                  },
                );
              }).toList(),
            ),

            const SizedBox(height: 30),

            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: enviarEvento,
                style: ElevatedButton.styleFrom(
                  backgroundColor: corBotao,
                  foregroundColor: corBranca,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: const Text(
                  'Enviar evento',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}