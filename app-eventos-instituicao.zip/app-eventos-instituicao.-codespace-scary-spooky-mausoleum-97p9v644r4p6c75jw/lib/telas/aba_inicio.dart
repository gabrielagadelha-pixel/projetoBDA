import 'package:flutter/material.dart';
import '../utils/cores.dart';
import '../utils/demanda_exemplo.dart';
import '../widgets/cabecalho_onda.dart';
import '../widgets/cartao_demanda.dart';
import '../widgets/logo_fasup.dart';
import '../widgets/solicitacoes_por_curso.dart';
import '../utils/cursos.dart';
import '../utils/sessao.dart';
import '../models/perfil_usuario.dart';

class AbaInicio extends StatelessWidget {
  const AbaInicio({super.key});

  @override
  Widget build(BuildContext context) {
   final usuario = Sessao.usuarioAtual;
    final nome = usuario?.nome ?? 'visitante';
    final perfil = usuario?.perfil.nome ?? '';
    final curso = usuario?.curso;
    final subtitulo =
        curso == null ? perfil : '$perfil · ${nomeCurto(curso)}';

    return Column(
      children: [
        CabecalhoOnda(
          altura: 170,
          child: Row(
            children: [
              GestureDetector(
                onTap: () => Scaffold.of(context).openDrawer(),
                child: const Icon(Icons.menu, color: corBranca, size: 28),
              ),
              const SizedBox(width: 12),
              Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(
                  color: corFundo,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const LogoFasup(tamanho: 64),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Olá, $nome!',
                      style: const TextStyle(
                        color: corBranca,
                        fontSize: 22,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                     subtitulo,
                      style: const TextStyle(
                        color: corBranca,
                        fontSize: 13,
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(
                Icons.notifications_none,
                color: corBranca,
                size: 28,
              ),
            ],
          ),
        ),
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Categorias',
                  style: TextStyle(
                    color: corEscura,
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 12),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      _categoria(Icons.celebration_outlined, 'Eventos'),
                      _categoria(Icons.share_outlined, 'Redes Sociais'),
                      _categoria(
                        Icons.menu_book_outlined,
                        'Material Institucional',
                      ),
                      _categoria(Icons.language, 'Publicação no site'),
                      _categoria(Icons.campaign_outlined, 'Endomarketing'),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
                SolicitacoesPorCurso(demandas: demandasExemplo),
                const SizedBox(height: 24),
                const Text(
                  'Demandas recentes',
                  style: TextStyle(
                    color: corEscura,
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 12),
                ...demandasExemplo.map(
                  (demanda) => CartaoDemanda(demanda: demanda),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _categoria(IconData icone, String texto) {
    return Container(
      width: 96,
      height: 84,
      margin: const EdgeInsets.only(right: 10),
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: corBranca,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: corBotao),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icone, color: corBotao, size: 28),
          const SizedBox(height: 6),
          Text(
            texto,
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: corEscura, fontSize: 11),
          ),
        ],
      ),
    );
  }
}