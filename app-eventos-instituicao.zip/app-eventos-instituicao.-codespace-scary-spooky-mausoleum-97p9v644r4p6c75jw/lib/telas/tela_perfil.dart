import 'package:flutter/material.dart';
import '../models/perfil_usuario.dart';
import '../models/usuario.dart';
import '../utils/cores.dart';
import '../utils/sessao.dart';
import '../widgets/cabecalho_onda.dart';

class TelaPerfil extends StatelessWidget {
  const TelaPerfil({super.key});

  Widget _linha(IconData icone, String rotulo, String valor) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        children: [
          Icon(icone, color: corCabecalho),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  rotulo,
                  style: const TextStyle(
                    color: corTextoSecundario,
                    fontSize: 12,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  valor,
                  style: const TextStyle(
                    color: corEscura,
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _cartaoDados(Usuario usuario) {
    final curso = usuario.curso;
    final inicial =
        usuario.nome.isEmpty ? '?' : usuario.nome[0].toUpperCase();

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: corBranca,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: corBotao),
      ),
      child: Column(
        children: [
          CircleAvatar(
            radius: 34,
            backgroundColor: corCabecalho,
            child: Text(
              inicial,
              style: const TextStyle(
                color: corBranca,
                fontSize: 28,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          const SizedBox(height: 12),
          _linha(Icons.person_outline, 'Nome', usuario.nome),
          const Divider(height: 1),
          _linha(Icons.email_outlined, 'E-mail', usuario.email),
          const Divider(height: 1),
          _linha(Icons.badge_outlined, 'Perfil', usuario.perfil.nome),
          if (curso != null) ...[
            const Divider(height: 1),
            _linha(Icons.school_outlined, 'Curso', curso),
          ],
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final usuario = Sessao.usuarioAtual;

    return Scaffold(
      backgroundColor: corFundo,
      body: Column(
        children: [
          CabecalhoOnda(
            altura: 130,
            child: Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.arrow_back, color: corBranca),
                  onPressed: () => Navigator.pop(context),
                ),
                const SizedBox(width: 8),
                const Text(
                  'Meu perfil',
                  style: TextStyle(
                    color: corBranca,
                    fontSize: 22,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(20),
              children: [
                if (usuario == null)
                  const Text(
                    'Nenhum usuário logado.',
                    style: TextStyle(color: corTextoSecundario),
                  )
                else
                  _cartaoDados(usuario),
              ],
            ),
          ),
        ],
      ),
    );
  }
}