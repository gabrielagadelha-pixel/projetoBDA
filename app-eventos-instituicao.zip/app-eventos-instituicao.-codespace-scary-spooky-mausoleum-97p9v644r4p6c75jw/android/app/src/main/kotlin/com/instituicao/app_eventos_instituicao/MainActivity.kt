package com.instituicao.app_eventos_instituicao

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
